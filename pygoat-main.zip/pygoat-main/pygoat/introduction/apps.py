from django.apps import AppConfig


class IntroductionConfig(AppConfig):
    name = 'introduction'
